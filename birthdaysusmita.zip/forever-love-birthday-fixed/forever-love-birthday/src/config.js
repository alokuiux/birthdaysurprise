// PERSONALIZE THIS FILE: change the name, messages, and photo captions.
// Importing images from src keeps paths compatible with Vite in development and production.
import photo1 from "./imagwa/ds.jpeg";
import photo2 from "./imagwa/dssv.jpeg";
import photo3 from "./imagwa/sskas.jpeg";
import photo4 from "./imagwa/vvx.jpeg";
import photo5 from "./imagwa/vxv.jpeg";
import photo6 from "./imagwa/WhatsApp Image 2026-11-24 at 10.22.02 PM.jpeg";

export const config = {
  wifeName: "My Beautiful Wife",
  nickname: "Susmita Sarker",
  fromName: "Your Love Alok",
  birthdayLine: "Today the world became more beautiful because you were born.",
  letter: [
    [
  "Happy Birthday, My Love! ❤️🎂 If I could give you one gift in this world, I would give you the ability to see yourself through my eyes. Only then would you truly understand how incredibly special, beautiful, and precious you are to me.",

  "Thank you for being my happiness, my comfort, and my favorite person. Thank you for every smile, every little moment, every memory, and every reason you give me to be grateful. Life feels more beautiful with you in it. ❤️",

  "On your special day, I wish you endless happiness, peaceful days, beautiful surprises, and the fulfillment of every dream your heart holds. May this new chapter of your life be filled with everything you deserve and even more.",

  "No matter how many birthdays come and go, I will keep choosing you, loving you, and making memories with you. Today, tomorrow, and in every lifetime. Happy Birthday, My Forever Love! ❤️✨"
]
  ],
  memories: [
    { src: photo1, caption: "A moment I want to keep forever" },
    { src: photo2, caption: "My favourite kind of happiness" },
    { src: photo3, caption: "Us, making little memories" },
    { src: photo4, caption: "Every day is better with you" },
    { src: photo5, caption: "One more reason to smile" },
    { src: photo6, caption: "My forever favourite person" }
  ]
};
