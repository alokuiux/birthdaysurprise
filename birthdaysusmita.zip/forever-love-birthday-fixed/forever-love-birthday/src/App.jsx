import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Heart, Gift, Images, Mail, Cake, Sparkles, ArrowLeft, ArrowRight, Music2, VolumeX } from "lucide-react";
import { config } from "./config";

const pages = ["Welcome", "Memories", "A Letter", "Birthday Cake", "Forever"];

function App() {
  const [page, setPage] = useState(0);
  const [lit, setLit] = useState(true);
  const [wish, setWish] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [music, setMusic] = useState(false);

  const next = () => setPage(p => Math.min(p + 1, pages.length - 1));
  const prev = () => setPage(p => Math.max(p - 1, 0));
  const go = (p) => { setPage(p); setShowMenu(false); window.scrollTo({ top: 0, behavior: "smooth" }); };

  return <main className="app">
    <div className="ambient"><span>♥</span><span>✦</span><span>♥</span><span>✧</span><span>♥</span></div>
    <header className="topbar">
      <button className="brand" onClick={() => go(0)}><Heart size={18} fill="currentColor"/> for my forever love</button>
      <button className="menu-toggle" onClick={() => setShowMenu(!showMenu)}>{showMenu ? "Close" : "Explore"} <Sparkles size={16}/></button>
      {showMenu && <nav className="dropdown">{pages.map((p,i)=><button key={p} onClick={()=>go(i)}>{String(i+1).padStart(2,"0")} — {p}</button>)}</nav>}
    </header>

    <div className="progress"><div style={{width: `${(page+1)/pages.length*100}%`}}/></div>

    <AnimatePresence mode="wait">
      <motion.section className="page" key={page} initial={{opacity:0,y:22}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-18}} transition={{duration:.35}}>
        {page === 0 && <section className="welcome panel">
          <div className="tiny-label"><Sparkles size={14}/> A LITTLE SURPRISE FOR YOU</div>
          <div className="hero-heart"><Heart fill="currentColor" strokeWidth={0}/><span>✦</span></div>
          <p className="script">To my favourite person</p>
          <h1>Happy Birthday,<br/><em>{config.nickname}</em></h1>
          <p className="lead">{config.birthdayLine}</p>
          <button className="primary" onClick={next}>Open your surprise <Gift size={17}/></button>
          <div className="hint">A little journey, made with all my love</div>
        </section>}

        {page === 1 && <section className="memories panel">
          <div className="tiny-label"><Images size={14}/> OUR LITTLE WORLD</div>
          <p className="script">The moments I treasure</p>
          <h2>Our beautiful memories</h2>
          <p className="lead">Every picture has a story. Every story has you.</p>
          <div className="gallery">{config.memories.map((m,i)=><motion.figure key={i} whileHover={{y:-7,rotate:i%2?1:-1}} className="polaroid">
            <img src={m.src} alt={m.caption} onError={e=>{e.currentTarget.style.visibility="hidden"}}/>
            <figcaption>{m.caption}</figcaption>
          </motion.figure>)}</div>
          <p className="small-note">You can replace every photo and caption in <code>src/config.js</code>.</p>
        </section>}

        {page === 2 && <section className="letter panel">
          <div className="tiny-label"><Mail size={14}/> WORDS FROM MY HEART</div>
          <div className="letter-card">
            <div className="seal"><Heart fill="currentColor" size={22}/></div>
            <p className="script">My dearest {config.wifeName},</p>
            <h2>A letter for you</h2>
            {config.letter.map((line,i)=><p className="letter-line" key={i}>{line}</p>)}
            <p className="script signoff">All my love, always.</p>
            <div className="signature">{config.fromName} ♡</div>
          </div>
        </section>}

        {page === 3 && <section className="cake-page panel">
          <div className="tiny-label"><Cake size={14}/> YOUR SPECIAL MOMENT</div>
          <p className="script">Make a wish, beautiful</p>
          <h2>A cake just for you</h2>
          <p className="lead">Close your eyes, make a wish, then tap the candles.</p>
          <div className="cake-wrap">
            <div className="candles">{[0,1,2].map(n=><button aria-label="Blow out candle" className="candle" key={n} onClick={()=>{setLit(false);setWish(true)}}><span className={lit?"flame":"flame out"}>{lit?"":" "}</span><i/></button>)}</div>
            <div className="icing"><span>♥</span><span>♥</span><span>♥</span></div>
            <div className="cake-layer layer-one"></div><div className="cake-layer layer-two"></div>
            <div className="plate"></div>
          </div>
          {wish ? <div className="wish-result"><h3>Your wish is on its way ✨</h3><p>May your days be as lovely as your heart.</p><button className="text-btn" onClick={()=>{setLit(true);setWish(false)}}>Light the candles again</button></div> : <button className="primary" onClick={()=>{setLit(false);setWish(true)}}>Blow out the candles <Sparkles size={17}/></button>}
        </section>}

        {page === 4 && <section className="final panel">
          <div className="final-orbit"><Heart fill="currentColor" strokeWidth={0}/><span>✦</span></div>
          <div className="tiny-label">ONE LAST THING</div>
          <p className="script">My today, my tomorrow</p>
          <h2>You are my<br/><em>always.</em></h2>
          <p className="lead">No matter how many birthdays come and go, my favourite gift will always be you.</p>
          <div className="final-line">Happy Birthday, {config.wifeName}!</div>
          <div className="signature">{config.fromName} <Heart size={15} fill="currentColor"/></div>
          <button className="primary" onClick={()=>go(0)}>Replay the surprise <Sparkles size={17}/></button>
        </section>}
      </motion.section>
    </AnimatePresence>

    <footer className="controls">
      <button className="nav-btn" onClick={prev} disabled={page===0}><ArrowLeft size={17}/> Back</button>
      <div className="dots">{pages.map((p,i)=><button key={p} aria-label={`Go to ${p}`} className={i===page?"dot active":"dot"} onClick={()=>go(i)}/>)}</div>
      <button className="nav-btn next" onClick={next} disabled={page===pages.length-1}>Next <ArrowRight size={17}/></button>
    </footer>
    <div className="page-count">{String(page+1).padStart(2,"0")} / {String(pages.length).padStart(2,"0")}</div>
  </main>;
}
export default App;